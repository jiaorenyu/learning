mkdir split
mkdir stat
python run.py user_pay.txt user_view.txt 2016-01-01 2016-10-31 split stat
